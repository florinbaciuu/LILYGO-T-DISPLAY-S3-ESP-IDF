#ifndef SKETCHPAD_MODEL_H_
#define SKETCHPAD_MODEL_H_

class SketchpadModel
{
private:
    /* data */
public:
    SketchpadModel(/* args */);
    ~SketchpadModel();
};




#endif