Open a PNG image from file and variable
"""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/png/lv_example_png_1
  :language: c

